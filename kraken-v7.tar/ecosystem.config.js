module.exports = {
  apps: [{
    name: "kraken",
    script: "src/index.js",
    cwd: __dirname,
    interpreter: "node",
    interpreter_args: "--experimental-sqlite",
    autorestart: true,
    max_restarts: 50,
    restart_delay: 3000,
    max_memory_restart: "300M",
    env: { NODE_ENV: "production" },
  }],
};
