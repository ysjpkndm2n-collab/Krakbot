module.exports = {
  apps: [{
    name: "kraken",
    script: "src/index.js",
    cwd: __dirname,
    interpreter: "node",
    interpreter_args: "--experimental-sqlite",
    autorestart: true,
    max_restarts: 50,
    restart_delay: 3000,
    exp_backoff_restart_delay: 200,
    min_uptime: 10000,
    kill_timeout: 8000,
    max_memory_restart: "300M",
    cron_restart: "0 5 * * *",
    env: { NODE_ENV: "production" },
  }],
};
