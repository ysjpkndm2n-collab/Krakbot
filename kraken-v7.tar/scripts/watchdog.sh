#!/bin/bash
# Watchdog: если heartbeat не обновлялся > 3 мин — жёстко перезапускаем бота.
# Ставится в cron раз в минуту:
#   * * * * * /home/ubuntu/kraken/scripts/watchdog.sh >> /home/ubuntu/kraken/data/watchdog.log 2>&1
HB="$(dirname "$0")/../data/.heartbeat"
NOW=$(date +%s)
if [ ! -f "$HB" ]; then exit 0; fi
LAST=$(cat "$HB" 2>/dev/null)
LAST=$((LAST / 1000))
DIFF=$((NOW - LAST))
if [ "$DIFF" -gt 180 ]; then
  echo "$(date '+%F %T') heartbeat застыл ${DIFF}s — рестарт kraken"
  pm2 restart kraken
fi
