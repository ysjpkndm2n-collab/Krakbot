"use strict";
/**
 * DriveApp + DocumentApp через синхронный Drive/Docs REST (curl).
 * Access token обновляется асинхронно в index.js и кладётся сюда setToken().
 * Используется только в фоновых задачах (syncQueue, flushPhotoQueue) —
 * не в горячем пути, так что синхронный curl тут ок.
 */
const { UrlFetchApp } = require("./urlfetch");

const TOKEN = { value: null };
function setToken(t) { TOKEN.value = t; }
function auth() { return { Authorization: "Bearer " + TOKEN.value }; }

const DRIVE = "https://www.googleapis.com/drive/v3";
const UPLOAD = "https://www.googleapis.com/upload/drive/v3";

function driveGet(pathQ) {
  const res = UrlFetchApp.fetch(DRIVE + pathQ, { method: "get", headers: auth(), muteHttpExceptions: true });
  return JSON.parse(res.getContentText() || "{}");
}

// ─────────── File ───────────
class DriveFile {
  constructor(meta) { this.meta = meta; }
  getId() { return this.meta.id; }
  getName() { return this.meta.name; }
  getBlob() {
    const res = UrlFetchApp.fetch(DRIVE + "/files/" + this.meta.id + "?alt=media",
      { method: "get", headers: auth(), muteHttpExceptions: true });
    return res.getBlob();
  }
  getUrl() { return "https://drive.google.com/file/d/" + this.meta.id + "/view"; }
  setTrashed(v) {
    UrlFetchApp.fetch(DRIVE + "/files/" + this.meta.id + "?supportsAllDrives=true",
      { method: "patch", contentType: "application/json",
        headers: auth(), payload: JSON.stringify({ trashed: !!v }), muteHttpExceptions: true });
    return this;
  }
}

// ─────────── Итератор файлов ───────────
function makeIterator(items, mapFn) {
  let i = 0;
  return {
    hasNext: () => i < items.length,
    next: () => mapFn(items[i++]),
  };
}

// ─────────── Folder ───────────
class DriveFolder {
  constructor(id) { this.id = id; }
  getId() { return this.id; }
  getFilesByType(mime) {
    const q = encodeURIComponent(`'${this.id}' in parents and mimeType='${mime}' and trashed=false`);
    let files = [], pageToken = null;
    do {
      const pt = pageToken ? "&pageToken=" + pageToken : "";
      const r = driveGet(`/files?q=${q}&fields=nextPageToken,files(id,name)&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true${pt}`);
      files = files.concat(r.files || []);
      pageToken = r.nextPageToken;
    } while (pageToken);
    return makeIterator(files, (m) => new DriveFile(m));
  }
  getFoldersByName(name) {
    const q = encodeURIComponent(`'${this.id}' in parents and mimeType='application/vnd.google-apps.folder' and name='${name.replace(/'/g, "\\'")}' and trashed=false`);
    const r = driveGet(`/files?q=${q}&fields=files(id,name)&supportsAllDrives=true&includeItemsFromAllDrives=true`);
    return makeIterator(r.files || [], (m) => new DriveFolder(m.id));
  }
  // Все подпапки этой папки (папки машин).
  getFolders() {
    const q = encodeURIComponent(`'${this.id}' in parents and mimeType='application/vnd.google-apps.folder' and trashed=false`);
    let items = [], pageToken = null;
    do {
      const pt = pageToken ? "&pageToken=" + pageToken : "";
      const r = driveGet(`/files?q=${q}&fields=nextPageToken,files(id,name)&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true${pt}`);
      items = items.concat(r.files || []);
      pageToken = r.nextPageToken;
    } while (pageToken);
    return makeIterator(items, (m) => new DriveFolder(m.id));
  }
  // Все файлы этой папки С датой создания (для автоудаления старых фото).
  // Возвращает массив объектов { id, name, createdTime (ISO) }.
  listFilesWithDates() {
    const q = encodeURIComponent(`'${this.id}' in parents and trashed=false`);
    let files = [], pageToken = null;
    do {
      const pt = pageToken ? "&pageToken=" + pageToken : "";
      const r = driveGet(`/files?q=${q}&fields=nextPageToken,files(id,name,createdTime,mimeType)&pageSize=1000&supportsAllDrives=true&includeItemsFromAllDrives=true${pt}`);
      files = files.concat(r.files || []);
      pageToken = r.nextPageToken;
    } while (pageToken);
    return files;
  }
  createFolder(name) {
    const res = UrlFetchApp.fetch(DRIVE + "/files?supportsAllDrives=true", {
      method: "post", contentType: "application/json", headers: auth(),
      payload: JSON.stringify({ name, mimeType: "application/vnd.google-apps.folder", parents: [this.id] }),
      muteHttpExceptions: true,
    });
    const j = JSON.parse(res.getContentText());
    return new DriveFolder(j.id);
  }
  createFile(blob) {
    const name = blob.getName ? blob.getName() : "file";
    const boundary = "xxKRKxx" + Date.now();
    const meta = { name, parents: [this.id] };
    const header = Buffer.from(
      "--" + boundary + "\r\n" +
      "Content-Type: application/json; charset=UTF-8\r\n\r\n" +
      JSON.stringify(meta) + "\r\n" +
      "--" + boundary + "\r\n" +
      "Content-Type: application/octet-stream\r\n\r\n", "utf8");
    const footer = Buffer.from("\r\n--" + boundary + "--\r\n", "utf8");
    const body = Buffer.concat([header, blob._buf, footer]);
    const res = UrlFetchApp.fetch(UPLOAD + "/files?uploadType=multipart&supportsAllDrives=true", {
      method: "post",
      contentType: "multipart/related; boundary=" + boundary,
      headers: auth(),
      payload: body,
      muteHttpExceptions: true,
    });
    const j = JSON.parse(res.getContentText());
    return new DriveFile(j);
  }
}

const DriveApp = {
  getFolderById(id) { return new DriveFolder(id); },
  getFileById(id) {
    const m = driveGet("/files/" + id + "?fields=id,name&supportsAllDrives=true");
    return new DriveFile(m);
  },
};

// ─────────── DocumentApp (только чтение текста OCR-дока) ───────────
const DocumentApp = {
  openById(id) {
    const res = UrlFetchApp.fetch(
      "https://docs.googleapis.com/v1/documents/" + id,
      { method: "get", headers: auth(), muteHttpExceptions: true });
    const doc = JSON.parse(res.getContentText() || "{}");
    let text = "";
    const content = (doc.body && doc.body.content) || [];
    for (const el of content) {
      if (el.paragraph && el.paragraph.elements) {
        for (const pe of el.paragraph.elements) {
          if (pe.textRun && pe.textRun.content) text += pe.textRun.content;
        }
      }
    }
    return { getBody: () => ({ getText: () => text }) };
  },
};

module.exports = { DriveApp, DocumentApp, setToken, _driveToken: TOKEN };
