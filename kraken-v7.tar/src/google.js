"use strict";
const { google } = require("googleapis");

const oauth2 = new google.auth.OAuth2(
  "151435070253-7mqbimtfibou9f8ue927mt1flhfo55l5.apps.googleusercontent.com",
  "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"
);
oauth2.setCredentials({
  refresh_token: "1//03bIc-1g5nGexCgYIARAAGAMSNwF-L9IrlqLaIGrYn8HSEGFiMlR3fvu8knU2nAKNkd8u4O1bRZEpLeXIQm7PHlPmMJLSxe3vphI"
});

let _sheets = null, _drive = null, _docs = null;
async function init() {
  _sheets = google.sheets({ version: "v4", auth: oauth2 });
  _drive = google.drive({ version: "v3", auth: oauth2 });
  _docs = google.docs({ version: "v1", auth: oauth2 });
}
async function getAccessToken() {
  const t = await oauth2.getAccessToken();
  return typeof t === "string" ? t : t.token;
}
module.exports = {
  init,
  getAccessToken,
  sheets: () => _sheets,
  drive: () => _drive,
  docs: () => _docs,
};
