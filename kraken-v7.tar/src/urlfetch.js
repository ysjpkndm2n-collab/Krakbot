"use strict";
/**
 * УСКОРЕННЫЙ UrlFetchApp (дроп-ин замена src/urlfetch.js).
 * Контракт тот же (синхронный, getContentText/getResponseCode/getBlob).
 * Что ускорено:
 *  - тело POST идёт в curl через stdin (--data-binary @-), а НЕ через запись
 *    временного файла на диск на каждый запрос (было: fs.writeFileSync+unlink);
 *  - --compressed (gzip ответы Telegram), --tcp-nodelay, --http1.1 keep-alive
 *    в рамках вызова, короче --max-time.
 * Замечание: главный сетевой тормоз — сам fork curl на каждый tg(). Полное
 * решение — async-переход в index.js (Promise/fetch с keep-alive агентом).
 * Этот файл — безопасный промежуточный шаг без изменения архитектуры.
 */
const { execFileSync } = require("child_process");

function buildResponse(bodyBuf, statusCode) {
  return {
    getContentText() { return bodyBuf.toString("utf8"); },
    getResponseCode() { return statusCode; },
    getBlob() {
      const buf = bodyBuf; let name = "blob";
      const blob = {
        _buf: buf,
        getBytes: () => Array.from(buf),
        getName: () => name,
        setName(n) { name = n; return blob; },
        copyBlob() { return blob; },
        getContentType: () => "application/octet-stream",
      };
      return blob;
    },
  };
}

const UrlFetchApp = {
  fetch(url, opts) {
    opts = opts || {};
    const args = ["-s", "-S", "--compressed", "--tcp-nodelay",
                  "-w", "\n__HTTP_STATUS__%{http_code}",
                  "--connect-timeout", "10", "--max-time", "60"];
    const method = (opts.method || "get").toUpperCase();
    if (method !== "GET") args.push("-X", method);

    const headers = opts.headers || {};
    if (opts.contentType) headers["Content-Type"] = opts.contentType;
    for (const k of Object.keys(headers)) args.push("-H", `${k}: ${headers[k]}`);

    let stdinBuf = null;
    if (opts.payload !== undefined && opts.payload !== null) {
      if (typeof opts.payload === "string") stdinBuf = Buffer.from(opts.payload, "utf8");
      else if (opts.payload && opts.payload._buf) stdinBuf = opts.payload._buf;
      else if (Buffer.isBuffer(opts.payload)) stdinBuf = opts.payload;
      else stdinBuf = Buffer.from(String(opts.payload), "utf8");
      args.push("--data-binary", "@-"); // тело через stdin, без temp-файла
    }
    args.push(url);

    // Хард-таймаут: даже если curl зависнет и проигнорит свой --max-time,
    // внешний `timeout --signal=KILL 65s` убьёт его, а execFileSync timeout — подстрахует.
    let cmd = "curl", cmdArgs = args;
    try {
      require("child_process").execFileSync("which", ["timeout"], { stdio: "ignore" });
      cmd = "timeout"; cmdArgs = ["--signal=KILL", "65s", "curl"].concat(args);
    } catch (e) { /* timeout нет — работаем голым curl */ }

    let out;
    try {
      out = execFileSync(cmd, cmdArgs, {
        input: stdinBuf || undefined,
        maxBuffer: 64 * 1024 * 1024,
        timeout: 70 * 1000,
        killSignal: "SIGKILL",
      });
    } catch (e) {
      if (!opts.muteHttpExceptions) throw e;
      out = e.stdout || Buffer.from("");
    }

    const marker = Buffer.from("__HTTP_STATUS__");
    const idx = out.lastIndexOf(marker);
    let body = out, status = 0;
    if (idx !== -1) {
      status = parseInt(out.slice(idx + marker.length).toString("utf8").trim(), 10) || 0;
      body = out.slice(0, idx);
      if (body.length && body[body.length - 1] === 0x0a) body = body.slice(0, body.length - 1);
    }
    return buildResponse(body, status);
  },
};

module.exports = { UrlFetchApp };
