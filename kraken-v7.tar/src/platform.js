"use strict";
/**
 * Мелкие утилиты Google Apps Script, которые реально использует бот:
 * форматирование дат, Blob для фото, Logger. Ничего лишнего.
 *
 * Того, что было в старом gas-shim только ради обхода лимитов Google
 * (кэш листов, ретраи, LockService, заглушки триггеров ScriptApp) — здесь нет:
 * без Google в горячем пути это не нужно.
 */
const TZ_OFFSET_MIN = Number(process.env.TZ_OFFSET_MIN || 120); // Europe/Warsaw летом +2ч

function pad(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }

function fmtLocal(date, fmt) {
  const d = new Date(date.getTime() + TZ_OFFSET_MIN * 60000); // VPS в UTC → локальное время
  const map = {
    yyyy: d.getUTCFullYear(),
    MM: pad(d.getUTCMonth() + 1, 2),
    dd: pad(d.getUTCDate(), 2),
    HH: pad(d.getUTCHours(), 2),
    mm: pad(d.getUTCMinutes(), 2),
    ss: pad(d.getUTCSeconds(), 2),
  };
  return fmt.replace(/yyyy|MM|dd|HH|mm|ss/g, (t) => map[t]);
}

const Utilities = {
  formatDate(date, tz, fmt) { return fmtLocal(date, fmt); },
  sleep(ms) { const end = Date.now() + ms; while (Date.now() < end) {} },
  newBlob(data, contentType, name) {
    const buf = Buffer.isBuffer(data)
      ? data
      : Buffer.from(typeof data === "string" ? data : data, "binary");
    return {
      _buf: buf,
      getBytes: () => Array.from(buf),
      setName(n) { name = n; return this; },
      getName: () => name,
      getContentType: () => contentType,
    };
  },
};

const Session = { getScriptTimeZone: () => process.env.TZ || "Europe/Warsaw" };
const Logger = { log: (...a) => console.log("[GAS]", ...a) };

// Заглушки для вещей, которые в GAS-версии были, но в Node-порту не работают.
// Триггеры заменены на setInterval в index.js; функции INSTALL_* в core их
// вызывают только при ручной установке — оставляем безопасные no-op.
const ScriptApp = {
  getProjectTriggers: () => [],
  newTrigger: () => ({
    timeBased: () => ({
      everyMinutes: () => ({ create: () => {} }),
      atHour: () => ({ everyDays: () => ({ create: () => {} }) }),
    }),
  }),
  deleteTrigger: () => {},
  getService: () => ({ getUrl: () => "" }),
};
const HtmlService = { createHtmlOutput: (s) => s };
const LockService = {
  getScriptLock: () => ({ tryLock: () => true, releaseLock: () => {}, waitLock: () => {} }),
};

module.exports = { Utilities, Session, Logger, ScriptApp, HtmlService, LockService };
