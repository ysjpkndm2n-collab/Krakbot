"use strict";
/**
 * PropertiesService (key/value настройки бота) поверх SQLite.
 * Раньше это был JSON-файл на диске; теперь та же база, что и данные —
 * одно место, один бэкап. Запись мгновенная и синхронная.
 */
const data = require("./data");

function db() { return data._db(); }

function init() {
  db().exec("CREATE TABLE IF NOT EXISTS props (k TEXT PRIMARY KEY, v TEXT);");
}

const scriptProps = {
  getProperty(k) {
    const r = db().prepare("SELECT v FROM props WHERE k=?").get(k);
    return r ? r.v : null;
  },
  setProperty(k, v) {
    db().prepare(
      "INSERT INTO props (k,v) VALUES (?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v"
    ).run(k, String(v));
    return this;
  },
  deleteProperty(k) {
    db().prepare("DELETE FROM props WHERE k=?").run(k);
    return this;
  },
  getProperties() {
    const out = {};
    for (const r of db().prepare("SELECT k,v FROM props").all()) out[r.k] = r.v;
    return out;
  },
};

const PropertiesService = { getScriptProperties: () => scriptProps };

module.exports = { init, PropertiesService };
