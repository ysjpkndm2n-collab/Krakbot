"use strict";
/**
 * ЛОКАЛЬНАЯ БАЗА (SQLite) вместо Google Sheets в горячем пути.
 *
 * Модель совместимости: бот (kraken.core.js) написан под Google Apps Script и
 * обращается к «листам» через getSheetByName / getRange / appendRow и т.д.
 * Здесь эти же вызовы реализованы поверх SQLite. Для core ничего не меняется —
 * он по-прежнему думает, что работает с таблицей.
 *
 * Каждый «лист» — это таблица SQLite с колонками c1..cN (по числу столбцов) и
 * служебным rn (номер строки, 1-based, как в таблице). Данные хранятся как есть
 * (строки/числа), пустая ячейка = "".
 *
 * Никаких сетевых запросов, никаких лимитов, никаких ретраев. Чтение и запись —
 * мгновенные и синхронные, как и ожидает синхронный код бота.
 */
const { DatabaseSync } = require("node:sqlite");
const path = require("path");
const fs = require("fs");

const DB_FILE = process.env.DB_FILE || path.join(__dirname, "..", "data", "kraken.db");

// Известные листы и их заголовки (первая строка). Порядок колонок = порядок в таблице.
// Источник — актуальная выгрузка KRAKEN_Workflow___База.xlsx.
const SCHEMA = {
  "Авто":          ["ID заказа","Госномер","Марка/Модель","Телефон","Стоимость (zł)","Тип заказа","Статус","Текущий этап","Кто работает","Старт этапа","План времени","Подрядная сумма","⚠️ Проверка","Создано"],
  "Доступы":       ["Машина","Подрядчик","Ставка","Статус","Когда"],
  "КлиентыСани":   ["Дата/время","Приёмщик","Событие","Минут"],
  "Безнал":        ["Дата/время","Сумма","Кто","Машина","Комментарий"],
  "КассаНал":      ["Дата/время","Тип","Сумма","Кто","Машина","Комментарий"],
  "Фирма":         ["Дата/время","Тип","Сумма","Источник","Кто","Комментарий"],
  "Смены":         ["Дата/время","Мастер","Событие","Гео","Минут","Коммент"],
  "Выплаты":       ["Когда","Мастер","Сумма","Кто выдал"],
  "Удалённые":     ["ID заказа","Когда","Кто удалил"],
  "Персонал":      ["PIN","Имя","Telegram ID","Роль","Может выдавать","Активен"],
  "Ставки":        ["Приоритет","Имя","Этап","Тип","Значение"],
  "Логи":          ["Дата/время","ID авто","Госномер","Мастер","Этап","План","Старт","Финиш","Факт (мин)","Начислено (zł)","Примечание"],
  "Корректировки": ["Дата","Имя","Сумма (±)","Причина","Кто внёс"],
  "Настройки":     ["Параметр","Значение","Описание"],
  "Фото":          ["Когда","Машина","Тип","Кто","Ссылка","Статус"],
  "Ошибки":        ["Когда","Где","Текст"],
  "Помощь":        ["Машина","Этап","Основной","Помощник","Сумма","Описание","Статус","Когда"],
};

// Сколько колонок держим в каждой таблице SQLite (с запасом на будущее).
const MAX_COLS = 24;

let db = null;

function tbl(name) {
  // Имя SQLite-таблицы: безопасное производное от имени листа.
  return "sheet_" + Buffer.from(name, "utf8").toString("hex");
}

function ensureTable(name) {
  const cols = [];
  for (let i = 1; i <= MAX_COLS; i++) cols.push(`c${i} TEXT DEFAULT ''`);
  db.exec(
    `CREATE TABLE IF NOT EXISTS ${tbl(name)} (` +
    `rn INTEGER PRIMARY KEY, ${cols.join(", ")});`
  );
}

function init() {
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  db = new DatabaseSync(DB_FILE);
  db.exec("PRAGMA journal_mode = WAL");   // быстрые и надёжные записи
  db.exec("PRAGMA synchronous = NORMAL");
  for (const name of Object.keys(SCHEMA)) {
    ensureTable(name);
    // если таблица пустая — кладём строку заголовков в rn=1
    const cnt = db.prepare(`SELECT COUNT(*) n FROM ${tbl(name)}`).get().n;
    if (cnt === 0) writeRow(name, 1, SCHEMA[name]);
  }
}

// ── низкоуровневые операции над строкой ──
function readRow(name, rn) {
  const r = db.prepare(`SELECT * FROM ${tbl(name)} WHERE rn=?`).get(rn);
  if (!r) return [];
  const out = [];
  for (let i = 1; i <= MAX_COLS; i++) out.push(r["c" + i] === null ? "" : r["c" + i]);
  // обрезаем хвост пустых
  let last = out.length;
  while (last > 0 && (out[last - 1] === "" || out[last - 1] === null)) last--;
  return out.slice(0, last);
}

function writeRow(name, rn, arr) {
  const vals = [];
  for (let i = 0; i < MAX_COLS; i++) {
    const v = arr[i];
    vals.push(v === undefined || v === null ? "" : String(v));
  }
  const cols = [];
  for (let i = 1; i <= MAX_COLS; i++) cols.push("c" + i);
  db.prepare(
    `INSERT INTO ${tbl(name)} (rn, ${cols.join(",")}) VALUES (?, ${cols.map(() => "?").join(",")}) ` +
    `ON CONFLICT(rn) DO UPDATE SET ${cols.map((c) => `${c}=excluded.${c}`).join(", ")}`
  ).run(rn, ...vals);
}

function lastRow(name) {
  const r = db.prepare(`SELECT MAX(rn) m FROM ${tbl(name)}`).get();
  return r && r.m ? r.m : 0;
}

// ── совместимый с GAS API ──
class Range {
  constructor(name, row, col, nr, nc) {
    this.n = name; this.r = row; this.c = col; this.nr = nr; this.nc = nc;
  }
  getValues() {
    const out = [];
    for (let i = 0; i < this.nr; i++) {
      const rowArr = readRow(this.n, this.r + i);
      const line = [];
      for (let j = 0; j < this.nc; j++) {
        const v = rowArr[this.c - 1 + j];
        line.push(v === undefined || v === null ? "" : v);
      }
      out.push(line);
    }
    return out;
  }
  getValue() { return this.getValues()[0][0]; }
  setValue(v) {
    const rowArr = readRow(this.n, this.r);
    while (rowArr.length < this.c) rowArr.push("");
    rowArr[this.c - 1] = v;
    writeRow(this.n, this.r, rowArr);
    return this;
  }
  setValues(vals) {
    for (let i = 0; i < vals.length; i++) {
      const rowArr = readRow(this.n, this.r + i);
      for (let j = 0; j < vals[i].length; j++) {
        while (rowArr.length < this.c + j) rowArr.push("");
        rowArr[this.c - 1 + j] = vals[i][j];
      }
      writeRow(this.n, this.r + i, rowArr);
    }
    return this;
  }
}

class Sheet {
  constructor(name) { this.name = name; }
  getName() { return this.name; }
  getLastRow() { return lastRow(this.name); }
  getLastColumn() {
    const last = lastRow(this.name);
    let max = 0;
    for (let rn = 1; rn <= last; rn++) {
      const len = readRow(this.name, rn).length;
      if (len > max) max = len;
    }
    return max;
  }
  getRange(row, col, nr, nc) { return new Range(this.name, row, col, nr || 1, nc || 1); }
  appendRow(arr) {
    const rn = lastRow(this.name) + 1;
    writeRow(this.name, rn, arr.slice());
    return this;
  }
  deleteRow(row) {
    // удаляем строку и сдвигаем все последующие вверх (как в таблице)
    const last = lastRow(this.name);
    db.exec("BEGIN");
    try {
      db.prepare(`DELETE FROM ${tbl(this.name)} WHERE rn=?`).run(row);
      for (let rn = row + 1; rn <= last; rn++) {
        const arr = readRow(this.name, rn);
        db.prepare(`DELETE FROM ${tbl(this.name)} WHERE rn=?`).run(rn);
        writeRow(this.name, rn - 1, arr);
      }
      db.exec("COMMIT");
    } catch (e) { db.exec("ROLLBACK"); throw e; }
    return this;
  }
  setFrozenRows() { return this; } // косметика таблицы — в БД не нужна
}

const SpreadsheetApp = {
  openById() {
    return {
      getSheetByName(name) {
        // существует, если это известный лист или таблица уже создана
        if (SCHEMA[name]) return new Sheet(name);
        const exists = db.prepare(
          "SELECT name FROM sqlite_master WHERE type='table' AND name=?"
        ).get(tbl(name));
        return exists ? new Sheet(name) : null;
      },
      insertSheet(name) {
        ensureTable(name);
        return new Sheet(name);
      },
    };
  },
  flush() {}, // всё пишется сразу, буфера нет
};

// ── экспорт «сырых» данных листа для зеркала в Google ──
function dumpSheet(name) {
  const last = lastRow(name);
  const rows = [];
  for (let rn = 1; rn <= last; rn++) rows.push(readRow(name, rn));
  return rows;
}
function replaceSheet(name, rows) {
  // Полная замена содержимого листа (используется зеркалом при импорте из Google).
  ensureTable(name);
  db.exec("BEGIN");
  try {
    db.prepare(`DELETE FROM ${tbl(name)}`).run();
    for (let i = 0; i < rows.length; i++) writeRow(name, i + 1, rows[i] || []);
    db.exec("COMMIT");
  } catch (e) { db.exec("ROLLBACK"); throw e; }
}
function allSheetNames() {
  const known = new Set(Object.keys(SCHEMA));
  const rows = db.prepare(
    "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'sheet_%'"
  ).all();
  for (const r of rows) {
    try { known.add(Buffer.from(r.name.slice(6), "hex").toString("utf8")); } catch (e) {}
  }
  return Array.from(known);
}

module.exports = {
  init, SpreadsheetApp, SCHEMA,
  dumpSheet, replaceSheet, allSheetNames,
  _db: () => db,
};
