"use strict";
/**
 * ЗЕРКАЛО: Google-таблица ↔ локальная база (SQLite).
 *
 * Зачем: база живёт локально (быстро, без лимитов), а Google-таблица остаётся
 * удобным «пультом» — туда можно зайти и поправить данные руками. Этот модуль
 * держит их согласованными, работая ФОНОМ (раз в минуту), а не на каждый клик.
 * Поэтому лимиты Google больше не влияют на скорость бота.
 *
 * Как решается «кто прав» при конфликте:
 *   - У каждого листа считаем хэш содержимого при последней синхронизации.
 *   - ИМПОРТ (Google → база): если лист в Google отличается от того, что мы
 *     туда в прошлый раз записали → значит человек правил руками → берём Google.
 *   - ЭКСПОРТ (база → Google): если лист в базе изменился с прошлой синхры →
 *     выгружаем в Google.
 *   - Если изменились ОБА одновременно (редко): приоритет у ручной правки в
 *     Google (человек важнее авто-записи), но такой лист логируется в консоль.
 *
 * Синхронизация идёт по одному листу за проход, чтобы не бить по лимитам залпом.
 */
const crypto = require("crypto");
const data = require("./data");

const SHEET_ID = process.env.SHEET_ID;

// снимок хэшей: lastHash[name] = { sheet: <хэш того, что в Google>, db: <хэш базы> }
const lastHash = {};

function hashRows(rows) {
  const norm = rows.map((r) => (r || []).map((c) => (c === undefined || c === null ? "" : String(c))));
  return crypto.createHash("sha1").update(JSON.stringify(norm)).digest("hex");
}

function colToA1(n) {
  let s = "";
  while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
  return s;
}

async function readSheetFromGoogle(sheets, name) {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SHEET_ID,
    range: `'${name.replace(/'/g, "''")}'`,
    valueRenderOption: "UNFORMATTED_VALUE",
    dateTimeRenderOption: "FORMATTED_STRING",
  }).catch((e) => {
    if (String(e.message || "").includes("Unable to parse range")) return null; // листа нет
    throw e;
  });
  if (!res) return null;
  return (res.data.values || []).map((r) => r.map((c) => (c === undefined || c === null ? "" : c)));
}

async function writeSheetToGoogle(sheets, name, rows) {
  // гарантируем, что лист существует
  const meta = await sheets.spreadsheets.get({ spreadsheetId: SHEET_ID, fields: "sheets(properties(title))" });
  const exists = meta.data.sheets.some((s) => s.properties.title === name);
  if (!exists) {
    await sheets.spreadsheets.batchUpdate({
      spreadsheetId: SHEET_ID,
      requestBody: { requests: [{ addSheet: { properties: { title: name } } }] },
    });
  }
  const values = rows.map((r) => (r || []).map((c) => (c === undefined || c === null ? "" : c)));
  const maxCols = values.reduce((m, r) => Math.max(m, r.length), 1);
  // очищаем и пишем заново (полная замена листа)
  await sheets.spreadsheets.values.clear({
    spreadsheetId: SHEET_ID,
    range: `'${name.replace(/'/g, "''")}'`,
  });
  if (values.length) {
    await sheets.spreadsheets.values.update({
      spreadsheetId: SHEET_ID,
      range: `'${name.replace(/'/g, "''")}'!A1:${colToA1(maxCols)}${values.length}`,
      valueInputOption: "RAW",
      requestBody: { values },
    });
  }
}

/**
 * Первичная загрузка при старте: если база пустая (только заголовки),
 * забираем всё, что есть в Google. Если в базе уже есть данные — не трогаем
 * (значит бот уже работал локально, Google подтянется обычной синхрой).
 */
async function initialImport(sheets) {
  let imported = 0;
  for (const name of Object.keys(data.SCHEMA)) {
    const local = data.dumpSheet(name);
    const hasData = local.length > 1; // >1 = есть что-то кроме заголовка
    if (hasData) continue;
    const remote = await readSheetFromGoogle(sheets, name);
    if (remote && remote.length > 1) {
      data.replaceSheet(name, remote);
      lastHash[name] = { sheet: hashRows(remote), db: hashRows(remote) };
      imported++;
    }
  }
  return imported;
}

/**
 * Один проход синхронизации по одному листу (round-robin).
 * Вызывается фоном из index.js. Возвращает короткий статус для лога.
 */
let cursor = 0;
async function syncOnePass(sheets) {
  const names = Object.keys(data.SCHEMA);
  const name = names[cursor % names.length];
  cursor++;

  const dbRows = data.dumpSheet(name);
  const dbHash = hashRows(dbRows);
  const remote = await readSheetFromGoogle(sheets, name);
  const remoteHash = remote ? hashRows(remote) : null;

  const prev = lastHash[name] || { sheet: null, db: null };
  const humanEdited = remote && remoteHash !== prev.sheet;   // Google изменился с прошлого раза
  const botEdited = dbHash !== prev.db;                      // база изменилась с прошлого раза

  if (humanEdited && botEdited) {
    // конфликт: побеждает ручная правка в Google
    data.replaceSheet(name, remote);
    lastHash[name] = { sheet: remoteHash, db: hashRows(remote) };
    return `⚠ конфликт на «${name}» → взял правку из Google`;
  }
  if (humanEdited) {
    data.replaceSheet(name, remote);
    lastHash[name] = { sheet: remoteHash, db: hashRows(remote) };
    return `↓ импорт «${name}» из Google`;
  }
  if (botEdited) {
    await writeSheetToGoogle(sheets, name, dbRows);
    lastHash[name] = { sheet: dbHash, db: dbHash };
    return `↑ экспорт «${name}» в Google`;
  }
  return null; // ничего не менялось
}

module.exports = { initialImport, syncOnePass };
