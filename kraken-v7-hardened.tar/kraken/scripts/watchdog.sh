#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────
# KRAKEN watchdog — внешний "сторож", независимый от самого Node-процесса.
#
# Идея: бот пишет файл data/.heartbeat каждый раз, когда успешно завершает
# круг опроса Telegram (обычно каждые несколько секунд). Если процесс
# ЗАВИСНЕТ (а не упадёт — pm2 сам чинит только падения), heartbeat перестанет
# обновляться. Этот скрипт запускается по cron раз в минуту, смотрит на
# "возраст" heartbeat-файла и, если тот протух — жёстко убивает процесс
# (SIGKILL), после чего pm2 (autorestart: true) поднимает бота заново.
#
# УСТАНОВКА (один раз):
#   chmod +x ~/kraken/scripts/watchdog.sh
#   crontab -e
#   и добавить строку:
#   * * * * * /home/ВАШ_ПОЛЬЗОВАТЕЛЬ/kraken/scripts/watchdog.sh >> /home/ВАШ_ПОЛЬЗОВАТЕЛЬ/kraken/data/watchdog.log 2>&1
#
# Проверить путь к себе: whoami && pwd (находясь в ~/kraken)
# ─────────────────────────────────────────────────────────────────────────

set -u

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HEARTBEAT_FILE="$DIR/data/.heartbeat"
APP_NAME="kraken"
MAX_AGE_SEC=180   # если heartbeat старше 3 минут — считаем бота зависшим
TS="$(date '+%Y-%m-%d %H:%M:%S')"

# Если heartbeat-файла ещё нет вовсе (первый запуск / только что установили) —
# ничего не делаем, даём боту время подняться.
if [ ! -f "$HEARTBEAT_FILE" ]; then
  echo "[$TS] heartbeat файл ещё не создан, пропускаю проверку"
  exit 0
fi

NOW_MS=$(($(date +%s%N) / 1000000))
LAST_MS=$(cat "$HEARTBEAT_FILE" 2>/dev/null || echo 0)
AGE_SEC=$(( (NOW_MS - LAST_MS) / 1000 ))

if [ "$AGE_SEC" -gt "$MAX_AGE_SEC" ]; then
  echo "[$TS] ⚠ heartbeat протух ($AGE_SEC сек, лимит $MAX_AGE_SEC) — процесс похоже завис. Жёсткий рестарт через pm2."

  # Находим PID процесса под pm2, чтобы добить его SIGKILL напрямую —
  # на случай если процесс настолько завис, что даже штатный `pm2 restart`
  # (который сначала пробует мягко) не пробьётся.
  PID=$(pm2 jlist 2>/dev/null | grep -A2 "\"name\":\"$APP_NAME\"" | grep -m1 '"pid"' | grep -o '[0-9]\+' || true)
  if [ -n "${PID:-}" ] && [ "$PID" != "0" ]; then
    kill -9 "$PID" 2>/dev/null && echo "[$TS] отправлен SIGKILL процессу PID=$PID"
  fi

  pm2 restart "$APP_NAME" --update-env
  echo "[$TS] pm2 restart $APP_NAME выполнен"
else
  echo "[$TS] ok, heartbeat свежий ($AGE_SEC сек назад)"
fi
