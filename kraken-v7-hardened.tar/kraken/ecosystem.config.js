module.exports = {
  apps: [{
    name: "kraken",
    script: "src/index.js",
    cwd: __dirname,
    interpreter: "node",
    interpreter_args: "--experimental-sqlite",
    autorestart: true,
    max_restarts: 50,
    // Если бот всё же упадёт несколько раз подряд (а не просто зависнет),
    // не долбим рестартами мгновенно — растущая пауза даёт сети/системе
    // время прийти в себя.
    exp_backoff_restart_delay: 200,
    restart_delay: 3000,
    min_uptime: "15s",
    // Сколько ждать перед SIGKILL при остановке/рестарте — если процесс
    // завис в execFileSync, штатный SIGTERM он не обработает, поэтому
    // держим этот таймаут небольшим.
    kill_timeout: 5000,
    max_memory_restart: "300M",
    // Профилактический перезапуск раз в сутки в тихий час (03:07 ночи) —
    // просто ещё один слой подстраховки на случай медленных утечек/дрейфа
    // состояния, которые не ловятся ни по памяти, ни по heartbeat.
    cron_restart: "7 3 * * *",
    env: { NODE_ENV: "production" },
  }],
};
