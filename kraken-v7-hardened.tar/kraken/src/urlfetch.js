"use strict";
/**
 * УСКОРЕННЫЙ UrlFetchApp (дроп-ин замена src/urlfetch.js).
 * Контракт тот же (синхронный, getContentText/getResponseCode/getBlob).
 * Что ускорено:
 *  - тело POST идёт в curl через stdin (--data-binary @-), а НЕ через запись
 *    временного файла на диск на каждый запрос (было: fs.writeFileSync+unlink);
 *  - --compressed (gzip ответы Telegram), --tcp-nodelay, --http1.1 keep-alive
 *    в рамках вызова, короче --max-time.
 * Замечание: главный сетевой тормоз — сам fork curl на каждый tg(). Полное
 * решение — async-переход в index.js (Promise/fetch с keep-alive агентом).
 * Этот файл — безопасный промежуточный шаг без изменения архитектуры.
 */
const { execFileSync } = require("child_process");

function buildResponse(bodyBuf, statusCode) {
  return {
    getContentText() { return bodyBuf.toString("utf8"); },
    getResponseCode() { return statusCode; },
    getBlob() {
      const buf = bodyBuf; let name = "blob";
      const blob = {
        _buf: buf,
        getBytes: () => Array.from(buf),
        getName: () => name,
        setName(n) { name = n; return blob; },
        copyBlob() { return blob; },
        getContentType: () => "application/octet-stream",
      };
      return blob;
    },
  };
}

const UrlFetchApp = {
  fetch(url, opts) {
    opts = opts || {};
    // ЖЁСТКИЙ таймаут в два слоя:
    //  1) --max-time / --connect-timeout самого curl — штатный способ.
    //  2) внешняя обёртка `timeout -k` — если curl вдруг НЕ среагирует на
    //     свой собственный --max-time (зависший DNS, полумёртвый TCP без RST
    //     и т.п.), coreutils timeout пошлёт SIGTERM, а через 5 сек добьёт
    //     SIGKILL. Так процесс Node физически не может зависнуть на fetch()
    //     дольше ~65 секунд, что бы ни случилось с сетью.
    const HARD_TIMEOUT_SEC = 65; // внешний "рубильник"
    // Синтаксис: timeout [--signal=SIG] DURATION COMMAND [ARGS...]
    const args = [
      "--signal=KILL", `${HARD_TIMEOUT_SEC}s`,
      "curl",
      "-s", "-S", "--compressed", "--tcp-nodelay",
      "--connect-timeout", "10", "--max-time", "60",
      "-w", "\n__HTTP_STATUS__%{http_code}",
    ];
    const method = (opts.method || "get").toUpperCase();
    if (method !== "GET") args.push("-X", method);

    const headers = opts.headers || {};
    if (opts.contentType) headers["Content-Type"] = opts.contentType;
    for (const k of Object.keys(headers)) args.push("-H", `${k}: ${headers[k]}`);

    let stdinBuf = null;
    if (opts.payload !== undefined && opts.payload !== null) {
      if (typeof opts.payload === "string") stdinBuf = Buffer.from(opts.payload, "utf8");
      else if (opts.payload && opts.payload._buf) stdinBuf = opts.payload._buf;
      else if (Buffer.isBuffer(opts.payload)) stdinBuf = opts.payload;
      else stdinBuf = Buffer.from(String(opts.payload), "utf8");
      args.push("--data-binary", "@-"); // тело через stdin, без temp-файла
    }
    args.push(url);

    let out;
    try {
      out = execFileSync("timeout", args, {
        input: stdinBuf || undefined,
        maxBuffer: 64 * 1024 * 1024,
        // Доп. подушка на уровне самого Node: даже если бинарник timeout
        // почему-то не убьёт curl, execFileSync сам пришлёт SIGKILL всему
        // дереву процессов по истечении этого времени.
        timeout: (HARD_TIMEOUT_SEC + 5) * 1000,
        killSignal: "SIGKILL",
      });
    } catch (e) {
      if (!opts.muteHttpExceptions) throw e;
      out = e.stdout || Buffer.from("");
    }

    const marker = Buffer.from("__HTTP_STATUS__");
    const idx = out.lastIndexOf(marker);
    let body = out, status = 0;
    if (idx !== -1) {
      status = parseInt(out.slice(idx + marker.length).toString("utf8").trim(), 10) || 0;
      body = out.slice(0, idx);
      if (body.length && body[body.length - 1] === 0x0a) body = body.slice(0, body.length - 1);
    }
    return buildResponse(body, status);
  },
};

module.exports = { UrlFetchApp };
