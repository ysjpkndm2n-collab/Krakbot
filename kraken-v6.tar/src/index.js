"use strict";
/**
 * KRAKEN — точка входа.
 *
 * Архитектура:
 *   • Данные бота живут в локальной базе SQLite (src/data.js). Чтение/запись —
 *     мгновенные, без сетевых лимитов. Весь горячий путь (обработка кнопок и
 *     сообщений) работает только с ней.
 *   • Google-таблица — «пульт» для ручных правок. Синхронизируется ФОНОМ
 *     (src/mirror.js), в обе стороны, раз в минуту. На скорость бота не влияет.
 *   • Google Drive используется только для фото и OCR протоколов — тоже фоном.
 *
 * Чего здесь больше НЕТ (было в старой версии ради обхода лимитов Sheets):
 *   – кэш чтения таблицы на 2.5с,
 *   – ретраи с задержками и детектор quota-ошибок,
 *   – watchdog-перезапуск процесса при «зависании».
 * Всё это лечило симптомы медленного Google в горячем пути. Пути больше нет.
 */
require("dotenv").config();

const data = require("./data");
const props = require("./props");
const platform = require("./platform");
const google = require("./google");
const driveShim = require("./drive-shim");
const mirror = require("./mirror");
const { UrlFetchApp } = require("./urlfetch");

const TG_TOKEN = process.env.TELEGRAM_TOKEN;
const ADMIN_CHAT = process.env.ADMIN_CHAT || "279014075";

if (!TG_TOKEN) { console.error("Нет TELEGRAM_TOKEN в .env"); process.exit(1); }
if (!process.env.SHEET_ID) { console.error("Нет SHEET_ID в .env (нужен для зеркала)"); process.exit(1); }

// Окружение, которое ожидает kraken.core.js (тот же контракт, что и в GAS).
const env = {
  SpreadsheetApp: data.SpreadsheetApp,
  PropertiesService: props.PropertiesService,
  Utilities: platform.Utilities,
  Session: platform.Session,
  Logger: platform.Logger,
  LockService: platform.LockService,
  ScriptApp: platform.ScriptApp,
  HtmlService: platform.HtmlService,
  UrlFetchApp,
  DriveApp: driveShim.DriveApp,
  DocumentApp: driveShim.DocumentApp,
  __SHEET_ID__: process.env.SHEET_ID,
  __DRIVE_TOKEN__: () => driveShim._driveToken.value,
};

const createKraken = require("./kraken.core");
let bot = null;

function tgSend(chatId, text) {
  try {
    UrlFetchApp.fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "post", contentType: "application/json", muteHttpExceptions: true,
      payload: JSON.stringify({ chat_id: chatId, text }),
    });
  } catch (e) {}
}
function alertAdmin(text) { tgSend(ADMIN_CHAT, text); }

// Последовательная очередь: апдейты и фоновые задачи не пересекаются во времени.
let queue = Promise.resolve();
function serial(fn) {
  queue = queue.then(fn).catch((e) => console.error("serial:", e && e.stack || e));
  return queue;
}

async function refreshDriveToken() {
  try { driveShim.setToken(await google.getAccessToken()); }
  catch (e) { console.error("token refresh:", e.message); }
}

// ── Telegram long polling ──
let offset = 0;
async function pollOnce() {
  const url = `https://api.telegram.org/bot${TG_TOKEN}/getUpdates?timeout=25&offset=${offset}`;
  let res;
  try { res = UrlFetchApp.fetch(url, { method: "get", muteHttpExceptions: true }); }
  catch (e) { console.error("poll fetch:", e.message); return; }

  let d;
  try { d = JSON.parse(res.getContentText()); } catch (e) { return; }
  if (!d.ok || !d.result || !d.result.length) return;

  for (const upd of d.result) {
    offset = upd.update_id + 1;
    await serial(() => {
      try {
        if (upd.message) bot.onMessage(upd.message);
        if (upd.callback_query) bot.onCallback(upd.callback_query);
      } catch (e) { console.error("update:", e && e.stack || e); }
    });
  }
}

async function pollLoop() {
  while (true) {
    try { await pollOnce(); }
    catch (e) { console.error("pollLoop:", e && e.stack || e); }
    await new Promise((r) => setTimeout(r, 300));
  }
}

// ── Фоновые задачи ──
function startBackground() {
  const sheets = google.sheets();

  // Внутренние тики бота (санитар, авто-паузы, дневная сводка).
  setInterval(() => serial(() => {
    try { bot.sanitarTick(); } catch (e) { console.error("sanitar:", e && e.stack || e); }
  }), 180 * 1000);

  setInterval(() => serial(() => {
    try { bot.idleCheckTick(); } catch (e) { console.error("idle:", e && e.stack || e); }
  }), 180 * 1000);

  // Drive: чтение протоколов и заливка фото (нужен свежий токен).
  setInterval(() => serial(async () => {
    await refreshDriveToken();
    try { bot.syncQueueTick(); } catch (e) { console.error("driveSync:", e && e.stack || e); }
  }), 15 * 60 * 1000);

  setInterval(() => serial(async () => {
    await refreshDriveToken();
    try { bot.flushPhotoQueue(); } catch (e) { console.error("photo:", e && e.stack || e); }
  }), 60 * 1000);

  // Дневная сводка в 23:00 локального времени.
  let lastReportDay = null;
  setInterval(() => serial(() => {
    const now = new Date(Date.now() + Number(process.env.TZ_OFFSET_MIN || 120) * 60000);
    const day = now.getUTCFullYear() + "-" + now.getUTCMonth() + "-" + now.getUTCDate();
    if (now.getUTCHours() === 23 && lastReportDay !== day) {
      lastReportDay = day;
      try { bot.dailyReportTick(); } catch (e) { console.error("report:", e && e.stack || e); }
    }
  }), 60 * 1000);

  // ЗЕРКАЛО Google ↔ база: один лист за проход, раз в ~4 секунды.
  // 17 листов проходятся за ~1 минуту, залпом по лимитам не бьём.
  setInterval(() => serial(async () => {
    try {
      const msg = await mirror.syncOnePass(sheets);
      if (msg) console.log("[mirror]", msg);
    } catch (e) { console.error("mirror:", e && e.stack || e); }
  }), 4 * 1000);
}

async function main() {
  console.log("KRAKEN запускается...");

  data.init();
  props.init();
  await google.init();
  await refreshDriveToken();
  setInterval(refreshDriveToken, 30 * 60 * 1000);

  // Первичный импорт из Google, если локальная база ещё пустая.
  try {
    const n = await mirror.initialImport(google.sheets());
    if (n) console.log(`Импортировано листов из Google при старте: ${n}`);
  } catch (e) { console.error("initialImport:", e && e.stack || e); }

  // Снимаем вебхук, включаем long polling.
  try {
    UrlFetchApp.fetch(`https://api.telegram.org/bot${TG_TOKEN}/deleteWebhook?drop_pending_updates=false`,
      { method: "get", muteHttpExceptions: true });
  } catch (e) {}

  bot = createKraken(env);

  startBackground();
  console.log("KRAKEN работает.");
  alertAdmin("✅ Бот запущен (локальная база + зеркало Google).");
  await pollLoop();
}

process.on("unhandledRejection", (e) => console.error("unhandledRejection:", e && e.stack || e));
process.on("uncaughtException", (e) => console.error("uncaughtException:", e && e.stack || e));

main().catch((e) => { console.error("FATAL:", e && e.stack || e); process.exit(1); });
